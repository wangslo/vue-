<template>
    <div class="sys-search">
        <slot></slot>
    </div>
</template>

<script>
export default {
    name: 'AppSearch'
}
</script>