<template>
    <div class="sys-notes">
        <slot></slot>
    </div>
</template>

<script>
export default {
    name: 'AppNotes'
}
</script>