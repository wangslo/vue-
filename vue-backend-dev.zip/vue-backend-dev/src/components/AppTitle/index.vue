<template>
    <div class="sys-title">
        <strong>{{title}}</strong>
    </div>
</template>

<script>
export default {
    name: 'AppTitle',
    props: ['title']
}
</script>