// 免登录白名单页面
const whiteList = [
    '/login',
    '/register',
    '/notice',
    '/maintenance'
]

export default whiteList