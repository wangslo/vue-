var data = {
    'token': '@guid'
}

export default [{
    path: '/getToken',
    data: data
}]