<template>
<div class="body">

  <center>
    <img src="../assets/logo.png" alt="" style="margin-top: 50px;width: 200px;">
    <h1 style="font-weight: 100;font-size: 35px;">基于vue 2 + element-ui 2 的后台管理平台模板</h1>
    <div class="text-center">
      <a href="https://github.com/mengdu/vue-element-admin-tpl">
        <m-button type="info" size="max" round >Github</m-button>
      </a>&nbsp;&nbsp;
      <a href="https://www.lanyueos.com">
        <m-button type="success" size="max" round plain>关于我</m-button>
      </a>
    </div>
  </center>
 
</div>
</template>
<script type="text/javascript">
export default {
  name: 'home'
}
</script>
<style type="text/css">
  .test{
    height: 40px;
    background: #ccc;
    margin-bottom: 15px;
  }
</style>
