import MCrop from './crop'

MCrop.install = function (Vue) {
  Vue.component(MCrop.name, MCrop)
}

export default MCrop
