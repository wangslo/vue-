import MBackTop from './back-top'

MBackTop.install = function (Vue) {
  Vue.component(MBackTop.name, MBackTop)
}

export default MBackTop
