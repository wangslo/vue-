## Loading 加载图标

加载等待图标组件

```html
<m-loading></m-loading>
<m-loading type="wipe"></m-loading>
```

## Loading Attributes

+ width 尺寸大小，字符串或者数字，默认40
+ type 类型，字符串，可选值：wipe
+ color 路径颜色，字符串
+ bg-color 背景路径颜色，字符串或boolean，默认true