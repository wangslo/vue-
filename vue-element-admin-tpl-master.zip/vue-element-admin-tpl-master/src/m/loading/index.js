import MLoading from './loading'

MLoading.install = function (Vue) {
  Vue.component(MLoading.name, MLoading)
}

export default MLoading
