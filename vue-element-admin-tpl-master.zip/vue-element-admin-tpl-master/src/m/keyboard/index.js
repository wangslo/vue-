import MKeyboard from './keyboard'

MKeyboard.install = function (Vue) {
  Vue.component(MKeyboard.name, MKeyboard)
}

export default MKeyboard
