import MSwitch from './switch'

MSwitch.install = function (Vue) {
  Vue.component(MSwitch.name, MSwitch)
}

export default MSwitch
