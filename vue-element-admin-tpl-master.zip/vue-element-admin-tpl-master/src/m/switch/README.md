## Switch 开关

```js
<m-switch v-model="status" >

```
# Switch Attributes

+ value Boolean 当前状态值
+ type 主题类型primary,success,danger,warning
+ size 大小 lg,sm
+ invert 反相主题
+ name input标签的name字段#
