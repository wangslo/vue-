import MAlert from './alert'


MAlert.install = function (Vue) {
  Vue.component(MAlert.name, MAlert)
}

export default MAlert
