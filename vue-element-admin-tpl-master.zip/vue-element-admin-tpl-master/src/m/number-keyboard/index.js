import MNumberKeyboard from './number-keyboard'

MNumberKeyboard.install = function (Vue) {
  Vue.component(MNumberKeyboard.name, MNumberKeyboard)
}

export default MNumberKeyboard
