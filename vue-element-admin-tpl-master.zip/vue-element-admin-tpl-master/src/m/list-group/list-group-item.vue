<template>
<div class="m-list-group-item">
  <slot></slot>
</div>
</template>
<script type="text/javascript">
export default {
  name: 'm-list-group-item'
}
</script>
