<template>
<ul class="m-dropdown-panel" @click.stop="">
  <slot></slot>
</ul>
</template>

<script type="text/javascript">
export default {
  name: 'MDropdownPanel'
}
</script>
