## Input

Input 输入框。

```html
<m-input placeholder="输入框">
```



### Input Attributes

+ disabled 禁用状态
+ type 类型input, text, password, textarea
+ size 大小 max, large, 默认, samll, mini
+ theme danger,success
+ placeholder 
+ block 块
+ maxHeight
+ maxWidth
+ minHeight
+ minWidth
+ width
+ height
