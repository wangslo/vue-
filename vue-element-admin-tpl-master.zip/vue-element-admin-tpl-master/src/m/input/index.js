import MInput from './input'

MInput.install = function (Vue) {
  Vue.component(MInput.name, MInput)
}

export default MInput
