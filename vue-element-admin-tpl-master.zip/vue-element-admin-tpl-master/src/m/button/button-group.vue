<template>
<div class="m-button-group">
  <slot></slot>
</div>
</template>
<script type="text/javascript">
export default {
  name: 'm-button-group'
}
</script>
