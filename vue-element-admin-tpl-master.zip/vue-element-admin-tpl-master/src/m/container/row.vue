<template>
<div class="m-row" 
  ><slot></slot></div>
</template>
<script>
export default {
  name: 'MRow'
}
</script>