import MLoader from './loader'

MLoader.install = function (Vue) {
  Vue.component(MLoader.name, MLoader)
}

export default MLoader
