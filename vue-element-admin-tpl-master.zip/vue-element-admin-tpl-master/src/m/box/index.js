import MBox from './box'

MBox.install = function (Vue) {
  Vue.component(MBox.name, MBox)
}

export default MBox
