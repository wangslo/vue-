import VMenu from './menu'

VMenu.install = function (Vue) {
  Vue.component(VMenu.name, VMenu)
}

export default VMenu
