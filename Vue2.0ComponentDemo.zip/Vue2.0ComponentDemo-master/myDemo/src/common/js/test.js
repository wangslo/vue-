export function a() {
 	alert(1)
}
// QRCode.prototype.a= function() {

// }