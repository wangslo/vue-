import * as types from './mutations-types'

const mutations = {
	[types.SET_A](state, a) {
		state.a =  a
	}
}
export default mutations