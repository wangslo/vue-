<template>
	<div class="transition">
		transition
	</div>
</template>
<script>
	export default {
		data() {
			return{

			}
		},
		mounted() {

		},
		methods: {

		}
	}
</script>
<style scoped>
	.transition{
		 width: 100px;
          height: 100px;
            background: red;
	}
</style>