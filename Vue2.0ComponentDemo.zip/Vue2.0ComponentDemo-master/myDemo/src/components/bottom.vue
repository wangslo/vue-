<template>
	<div class="fd-bottom">
		<div class="bottom" >
			<ul>
				<li>1</li>
				<li>2</li>
				<li>3</li>
				<li>4</li>
			</ul>
		</div>
	</div>
</template>
<script>
	export default {
		name: 'bottom'
	}
</script>


<style lang='less'>
	.fd-bottom{
		.bottom{
			ul{
				li{
					float: left;
				}
			}
		}
	}
</style>