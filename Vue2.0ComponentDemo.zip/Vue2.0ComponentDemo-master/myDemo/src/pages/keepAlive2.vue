<template>
	<div class="keepAlive2">
		1123
	</div>
</template>
<script>
	export default {
		data() {
			return{
				
			}
		}
	}
</script>