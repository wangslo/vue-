const state = {
	a:''
}
export default state